"""用你的 DataPack + 假價格測試。價格是假的，只用來驗證程式邏輯。"""
from datapack import load_datapack, print_summary
from derive_orders import derive_orders, preview_portfolio

state = load_datapack("inputs/2026-10-23/datapack.json")
print_summary(state)

fake_prices = {"2330": 2585, "2454": 4920, "2317": 256, "2308": 2050, "3711": 744,
    "2881": 154.5, "2882": 112, "2891": 68.4, "2884": 45.45, "2886": 40, "2885": 30,
    "2887": 41.45, "2890": 45.4, "2412": 140, "2345": 2050, "3231": 189.5, "2382": 280,
    "3017": 3685, "2357": 520, "3034": 400, "2379": 600, "2303": 60, "6669": 2290,
    "3037": 1310, "2327": 700}
weights = {"2330": .18, "2454": .05, "2317": .05, "2308": .05, "3711": .04, "2881": .04,
    "2882": .04, "2891": .04, "2884": .035, "2886": .035, "2885": .035, "2887": .035,
    "2890": .035, "2412": .035, "2345": .03, "3231": .03, "2382": .03, "3017": .03,
    "2357": .03, "3034": .03, "2379": .03, "2303": .03, "6669": .03, "3037": .03}
decisions = [{"decision_id": f"D{i+1}", "ticker": t, "action": "BUY", "target_weight": w}
             for i, (t, w) in enumerate(weights.items())]

orders = derive_orders(decisions, state, fake_prices)
report, problems = preview_portfolio(orders, state, fake_prices)
print(orders[0]["derivation_detail"])
print(f"委託 {len(orders)} 筆 | 持股 {report['holdings_count']} 檔 | 現金比 {report['cash_ratio']:.1%} | 淨買入 {report['net_flow_pct_nav']:.1%} NAV")
print("問題:", problems or "無，可以繳交")